#!/bin/bash

echo "Valoare curenta umask: "$(umask)
mkdir -p  mydir/
touch mydir/myfile.txt
echo "Permisiuni mydir: $(stat -c "%A" mydir)"
echo "Permisiuni myfile.txt:  $(stat -c "%A" mydir/myfile.txt)"
## Puteam folosi la fel de bine si echo $(ls -l mydir/myfile.txt | cut -c 1-10)  dar este mai la indemana stat
umask 077
touch mydir/myfile2.txt
echo "Permisiuni myfile2.txt: " "$(stat -c "%A" mydir/myfile2.txt)"

## Comentariu:
## Se observa ca in urma modificarii umask la valoarea 077, permisiunile standard al fiserelor create
## (666-002=664) rw-rw-r--  obtinem permisiunile (666-077=600) rw------- 
