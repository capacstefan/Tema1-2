
#!/bin/bash

read -p "Nume fisier:" fisier
if [ ! -e "$fisier" ]; then
	echo "Fisier invalid"
	exit 1
fi

perm=$(stat -c '%a' "$fisier")

uperm=$((perm/100))
gperm=$(( (perm/10) % 10 ))
operm=$((perm%10))

permisiuni(){
val=$1
user=$2
fis=$3
case $val in
	7)
	  perm_lit="rwx"
	  ;;
	6)
	  perm_lit="rw-";
          [[ "$user" == "u" ]] && chmod u+x $fis;
	  [[ "$user" == "g" ]] && chmod g+x $fis ;
	  [[ "$user" == "o" ]] && chmod o+x $fis  
 	  ;;
	5)
	  perm_lit="r-x";
	  [[ "$user" == "u" ]] && chmod u+w $fis;
          [[ "$user" == "g" ]] && chmod g+w $fis ;
          [[ "$user" == "o" ]] && chmod o+w $fis
     	  ;;
	4)
	  perm_lit="r--";
	  [[ "$user" == "u" ]] && chmod u+wx $fis;
          [[ "$user" == "g" ]] && chmod g+wx $fis ;
          [[ "$user" == "o" ]] && chmod o+wx $fis
          ;;
	3)
 	  perm_lit="-wx";
	  [[ "$user" == "u" ]] && chmod u+r $fis;
          [[ "$user" == "g" ]] && chmod g+r $fis ;
          [[ "$user" == "o" ]] && chmod o+r $fis
          ;;
	2)
	  perm_lit="-w-";
	  [[ "$user" == "u" ]] && chmod u+rx $fis;
          [[ "$user" == "g" ]] && chmod g+rx $fis ;
          [[ "$user" == "o" ]] && chmod o+rx $fis
          ;;
	1)
	  perm_lit="--x";
	  [[ "$user" == "u" ]] && chmod u+rw $fis;
          [[ "$user" == "g" ]] && chmod g+rw $fis ;
          [[ "$user" == "o" ]] && chmod o+rw $fis
          ;;
	0)
   	  perm_lit="---";
	  [[ "$user" == "u" ]] && chmod u+rwx $fis;
          [[ "$user" == "g" ]] && chmod g+rwx $fis ;
          [[ "$user" == "o" ]] && chmod o+rwx $fis
          ;;
esac
echo -n "$perm_lit"
}
permisiuni "$uperm" "u" "$fisier"
permisiuni "$gperm" "g" "$fisier" 
permisiuni "$operm" "o" "$fisier"
 
echo ""
