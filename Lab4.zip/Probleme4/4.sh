#!/bin/bash

[ -d project ] && rm -r project
mkdir -p project/{src,bin}
touch project/src/main.sh
chmod 754 project/src/main.sh
touch project/bin/output.log
chmod u+rwx,g+r,o+r project/bin/output.log
