#!/bin/bash

threshold=10
used_space=$(df / | tail -1 | awk '{print $5}' | cut -d '%' -f 1)

if [ "$used_space" -ge $((100 - "$threshold")) ]; then
	echo "Limita utilizare spatiu depasita"
else
	echo "Spatiul pe disc este suficient"
fi

## Observatie
## Am folosit awk '{print$5}' in loc de (cut -d ' ' -f 5) deoarece aceasta metoda
## va genera la folosirea in if a variabilei 
## o eroare(integer expression expected)

