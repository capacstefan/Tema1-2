#!/bin/bash

dir="director"
[ ! -d "$dir" ] && mkdir director
touch "$dir"/f{1,2,3,4,5}

chmod 751 "$dir" 

verif_modif(){
f=$1
permvechi=$(ls -l "$f" | cut -c 2-9)
if [[ "$permvechi" != "rw-r-r-" ]]; then
	chmod 644 "$f"
fi
}

verif_modif "$dir"/f1
verif_modif "$dir"/f2
verif_modif "$dir"/f3
verif_modif "$dir"/f4
verif_modif "$dir"/f5
