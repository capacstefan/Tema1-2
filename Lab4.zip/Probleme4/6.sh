#!/bin/bash

read -p "Introdu cale director/fisier: " doc

select option in "Verificarea permisiunilor actuale." "Setarea permisiunilor la rwxr-xr-x." "Setarea permisiunilor la rw-r-r-." "Iesire."
do
case $option in
	"Verificarea permisiunilor actuale.")
	stat -c "%A" "$doc"
	;;
	"Setarea permisiunilor la rwxr-xr-x.")
	chmod 755 "$doc"
	;;
	"Setarea permisiunilor la rw-r-r-.")
	chmod 644 "$doc"
	;;
	"Iesire.")
	exit 0
	;;
esac
done
