#!/bin/bash

if [[ "$(umask)" == "0022" || "$(umask)" == "022" ]] ;then 
	echo "umask este deja 022"
else
	umask 002
	echo "umask a fost setata la 022"
fi

## Observatii:
## Mask-ul setat va fi valabil doar pe durata rularii scriptului, odata terminat, vom constata folosind comanda
## umask ca avem acekasi mask ca inainte de executie
