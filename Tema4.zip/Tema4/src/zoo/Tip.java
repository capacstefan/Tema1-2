package zoo;
/**
 * Enumeratie tipuri animale
 */
public enum Tip {
	ERBIVOR,
	CARNIVOR
}
