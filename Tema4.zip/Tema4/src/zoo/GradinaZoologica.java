package zoo;

import java.util.ArrayList;
import java.util.List;

public class GradinaZoologica {

	private String nume;
	private static ArrayList<Animal> animale;
	
	public GradinaZoologica() {}
	
	public GradinaZoologica(String n, ArrayList<Animal> a) {
		nume = n;
		animale = a;
	}
	
	public double getHranaZiErbivore() {
		double totalHrana = 0;
		for(Animal animal : animale) 
			if(animal.getTip() == Tip.ERBIVOR)
				totalHrana += animal.getHranaZi();
		return totalHrana;
	}
	
	public double getHranaZiCarnivore() {
		double totalHrana = 0;
		for(Animal animal : animale) 
			if(animal.getTip() == Tip.CARNIVOR)
				totalHrana += animal.getHranaZi();
		return totalHrana;
	}
	
	public double getHranaLunaErbivore() {
		return getHranaZiErbivore() * 30;
	}
	
	public double getHranaLunaCarnivore() {
		return getHranaZiCarnivore() * 30;
	}
	
	public ArrayList<Animal> getErbivore() {
		ArrayList<Animal> erbivore = new ArrayList<>();
		for(Animal animal : animale)
			if(animal.getTip() == Tip.ERBIVOR)
				erbivore.add(animal);
		return erbivore;
				
	}
	
	public ArrayList<Animal> getCarnivore(){
		ArrayList<Animal> carnivore = new ArrayList<>();
		for(Animal animal : animale)
			if(animal.getTip() == Tip.CARNIVOR)
				carnivore.add(animal);
		return carnivore;
	}
	
	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append(nume+"\n");
		for(Animal animal : animale)
			s.append(animal.toString()+"\n");
		return s.toString();
	}
	
	public static  <T extends Animal> List<T> listaAnimalSpecificat(Class<T> animalSpecific){
		List<T> animaleSpecificate = new ArrayList<>();
		for(Animal animal : animale)
			if(animalSpecific.isInstance(animal))
				animaleSpecificate.add(animalSpecific.cast(animal));
		return animaleSpecificate;
	}
}
