package zoo;

public class Leu extends Animal {
	/**
	  * Constructor implicit
	  */
	public Leu() {}
	/**
	 * Constructor paramtrizabil
	 * @param z
	 */
	public Leu(double z) {
		super(z,Tip.CARNIVOR);
	}
	/**
	 * Suprascriere metoda convertire String
	 */
	@Override
	public String toString() {
		return "Leu, este "+tip+" si mananca "+hranaZi+"kg pe zi";
	}

}
