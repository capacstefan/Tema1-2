package zoo;

public class Elefant extends Animal {
	/**
	  * Constructor implicit
	  */
	public Elefant() {}
	/**
	 * Constructor paramtrizabil
	 * @param z
	 */
	public Elefant(double z) {
		super(z,Tip.ERBIVOR);
	}
	/**
	 * Suprascriere metoda convertire String
	 */
	@Override
	public String toString() {
		return "Elefant, este "+tip+" si mananca "+hranaZi+"kg pe zi";
	}
}
