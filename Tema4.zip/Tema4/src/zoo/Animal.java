package zoo;

public abstract class Animal {
	/**
	 * Campuri
	 */
	protected double hranaZi;
	protected Tip tip;
	 /**
	  * Constructor implicit
	  */
	public Animal() {}
	/**
	 * Constructor paramtrizabil
	 * @param z
	 */
	public Animal(double z,Tip t) {
		hranaZi = z;
		tip = t;
	}
	/**
	 * Metoda get hrana zilnica
	 * @return
	 */
	public double getHranaZi() {
		return hranaZi;
	}

	/**
	 * Metoda get tip
	 * @return
	 */
	public Tip getTip() {
		return tip;
	}
	
	/**
	 * Metoda abstracta convertire String
	 */
	public abstract String toString();
}
