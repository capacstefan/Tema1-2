package zoo;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		
		Elefant e = new Elefant(43.5);
		Elefant e2 = new Elefant(41.0);
		Flamingo f = new Flamingo(1.3);
		Leu l = new Leu(15.8);
		Strut s = new Strut(3.1);
		Tigru t = new Tigru(13.3);
		
		ArrayList<Animal> animale = new ArrayList<>();
		animale.add(e);
		animale.add(e2);
		animale.add(f);
		animale.add(l);
		animale.add(s);
		animale.add(t);
		
		GradinaZoologica zoo = new GradinaZoologica("Parcul Romanescu",animale);
		
		System.out.println(zoo.toString());
		
		System.out.println("Hrana totala erbivore: zi -> "+zoo.getHranaZiErbivore()+"kg luna -> "+zoo.getHranaLunaErbivore()+"kg"
		+"\nHrana totala carnivore: zi -> "+zoo.getHranaZiCarnivore()+"kg luna -> "+zoo.getHranaLunaCarnivore()+"kg"+"\n");
		
		ArrayList<Animal> erbivore = zoo.getErbivore();
		ArrayList<Animal> carnivore = zoo.getCarnivore();				
		
		System.out.println("Erbivore:");
		for(Animal animal : erbivore)
			System.out.println(animal.toString());
		System.out.println();
		
		System.out.println("Carnivore:");
		for(Animal animal : carnivore)
			System.out.println(animal.toString());
		
		List<Elefant> elefanti = GradinaZoologica.listaAnimalSpecificat(Elefant.class);
		System.out.println("\nEnumerare elefanti:");
		for(Animal animal : elefanti )
			System.out.println(animal.toString());
	}

}
