package zoo;

public class Flamingo extends Animal {
	/**
	  * Constructor implicit
	  */
	public Flamingo() {}
	/**
	 * Constructor paramtrizabil
	 * @param z
	 */
	public Flamingo(double z) {
		super(z,Tip.ERBIVOR);
	}
	/**
	 * Suprascriere metoda convertire String
	 */
	@Override
	public String toString() {
		return "Flamingo, este "+tip+" si mananca "+hranaZi+"kg pe zi";
	}
}
