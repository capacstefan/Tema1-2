package zoo;

public class Tigru extends Animal {
	/**
	  * Constructor implicit
	  */
	public Tigru() {}
	/**
	 * Constructor paramtrizabil
	 * @param z
	 */
	public Tigru(double z) {
		super(z,Tip.CARNIVOR);
	}
	/**
	 * Suprascriere metoda convertire String
	 */
	@Override
	public String toString() {
		return "Tigru, este "+tip+" si mananca "+hranaZi+"kg pe zi";
	}
}
