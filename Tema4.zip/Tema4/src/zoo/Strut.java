package zoo;

public class Strut extends Animal {
	
	/**
	  * Constructor implicit
	  */
	public Strut() {}
	/**
	 * Constructor paramtrizabil
	 * @param z
	 */
	public Strut(double z) {
		super(z,Tip.ERBIVOR);
	}
	/**
	 * Suprascriere metoda convertire String
	 */
	@Override
	public String toString() {
		return "Strut, este "+tip+" si mananca "+hranaZi+"kg pe zi";
	}

}
