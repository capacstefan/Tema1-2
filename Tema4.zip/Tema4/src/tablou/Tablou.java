package tablou;

public class Tablou {
	public static <T> void interSchimba(T[] tablou, int i1, int i2) {
		if(i1 < 0 || i2 < 0 || i1 >= tablou.length || i2 >= tablou.length)
			System.out.println("Indici invalizi");
		T temp = tablou[i1];
		tablou[i1] = tablou[i2];
		tablou[i2] = temp;
	}
	
	public static void main(String[] args) {
		Integer[] tablou= {1,2,3,4,5,6,7};
		
		for(Integer el : tablou)
			System.out.print(el+" ");
		System.out.println();
		
		interSchimba(tablou,1,3);
		
		for(Integer el : tablou)
			System.out.print(el+" ");
		
		System.out.println();
		System.out.println();
		
		
		
		Double[] tablou1 = {1.0,1.3,3.8,2.1,8.0,9.1,0.3};
		
		for(Double el : tablou1)
			System.out.print(el+" ");
		System.out.println();
		
		interSchimba(tablou1,2,5);
		
		for(Double el : tablou1)
			System.out.print(el+" ");
	}
	
}
