package nrElemente;

import java.util.Collection;
import java.util.function.Predicate;

public class Colectie {
	
	public static <T> int counterProprietate(Collection<T> colectie, Predicate<T> proprietate) {
		int count = 0;
		for(T x : colectie)
			if(proprietate.test(x))
				count++;
		return count;
	}
	
	public static boolean prim(Object o) {
		if(!(o instanceof Integer))
			return false;
		Integer n = (Integer) o;
		if(n<2)
			return false;
		for(int i = 2; i <= n/2+1; i++)
			if(n % i == 0)
				return false;
		return true;
	}
	
	public static boolean palindrom(Object o) {
		if(!(o instanceof Integer))
			return false;
		Integer n = (Integer) o;
		String s = Integer.toString(n);
		return s.equals(new StringBuilder(s).reverse().toString());
	}
	
	public static boolean impar(Object o) {
		if(!(o instanceof Integer))
			return false;
		Integer n = (Integer) o;
		return n % 2 != 0;
	}
}
