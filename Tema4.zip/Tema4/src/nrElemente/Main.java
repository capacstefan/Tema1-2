package nrElemente;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		List<Object> lista = new ArrayList<>();
		lista.add(3);
		lista.add(666);
		lista.add("Caine");
		lista.add(8);
		lista.add(763);
		lista.add(5.34);
		lista.add(1001);
		lista.add("Catelus");
		
		int nrPrime = Colectie.counterProprietate(lista,Colectie::prim);
		System.out.println("nr numere prime: "+nrPrime);
		
		int nrImpare = Colectie.counterProprietate(lista, Colectie::impar);
		System.out.println("nr numere impare: "+ nrImpare);
		
		int nrPalindrom = Colectie.counterProprietate(lista, Colectie::palindrom);
		System.out.println("nr numere palindrom: "+ nrPalindrom);
		
		
	}


}
