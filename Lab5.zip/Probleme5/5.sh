#!/bin/bash

select option in "Monitorizare memorie" "Monitorizare procesor" "Monitorizare ambele" "Exit";do
case "$option" in	
	"Monitorizare memorie") while true; do
		clear
		ps -e -o pid,%mem
		sleep 5
	   done;;
	"Monitorizare procesor") while true; do
		clear
		ps -e -o pid,%cpu
		sleep
	   done;;
	"Monitorizare ambele") while true; do
		clear
		ps -e -o pid,%mem,%cpu
		sleep 5
	   done;;
	"Exit") exit 0;;
esac
done
