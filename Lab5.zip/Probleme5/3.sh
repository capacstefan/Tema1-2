#!/bin/bash

export MYVAR="xxxxxxxxxxxxxxx"

for var in $(env | cut -d '=' -f 1); do
	echo "$var"
done

if [[ ! -z "$MYVAR" ]]; then
	echo "Variabila este setata $MYVAR, umreaza stergerea"
	unset MYVAR
else
	echo ${MYVAR:-"Valoare implicita"}
fi
