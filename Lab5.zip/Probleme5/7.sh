#!/bin/bash

uid=$(id -u)
gid=$(id -g)

read -p "Introdu cale director: " dir

for fis in "$dir"/*;do
	if [[ -f "$fis" ]]; then
		fisuid=$(stat -c "%u" "$fis")
		fisgid=$(stat -c "%g" "$fis")
		if [[ "$uid" -eq "$fisuid" && "$gid" -eq "$fisgid" ]]; then
			echo "$fis : permis"
			chmod u+rwx "$fis"
		else
			echo "$fis : nepermis $uid:$gid $fisuid:$fisgid" >&2
		fi
	fi
done
