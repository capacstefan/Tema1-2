#!/bin/bash

uid=$(id -u)
gid=$(id -g)

while true; do
## Comanda ps(process status) este utiliz pentru a afisa informatii despre procesele
## in derulare. Optiunea -u specifica userul iar -o formatul respectiv
## ( id proces, comanda pentru a identifica mai usor, si memorie)
	ps -u "$uid" -o pid,comm,%mem
	sleep 5
done
