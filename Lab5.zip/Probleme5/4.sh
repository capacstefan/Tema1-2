#!/bin/bash 

uid=$(id -u)
read -p "Introdu cale director: " dir

for fis in "$dir"/*;do
	if [[ -f "$fis" ]]; then
		if [[ $uid -eq 0 ]]; then
			chmod 777 "$fis"
		else
			chmod 666 "$fis"
		fi
	fi
done
