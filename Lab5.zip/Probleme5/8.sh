#!/bin/bash
[ ! -e "original.txt" ] && touch original.txt 
read -p "Introdu cale director:" dir
ln original.txt "$dir"/hardlink.txt
## pwd cale absoluta  pentru functionare corecta altfel eroare no such file 
ln -s "$(pwd)/original.txt" "$dir"/softlink.txt
original_inode=$(stat -c "%i" original.txt)
hardlink_inode=$(stat -c "%i" "$dir"/hardlink.txt)
softlink_inode=$(stat -c "%i" "$dir"/softlink.txt)
echo "---Verificare inode-uri fisiere"
echo "original.txt -> inode=$original_inode" 
echo "hardlink.txt -> inode=$hardlink_inode"
echo "softlink.txt -> inode=$softlink_inode"
if [[ "$original_inode" == "$hardlink_inode" ]]; then
	echo "original.txt si  hardlink.txt au acelasi inode"
else
	echo "original.txt si hardlink.txt nu au acelasi inode"
fi

if [[ "$original_inode" == "$softlink_inode" ]]; then
        echo "original.txt si softlink.txt au acelasi inode"
else
        echo "original.txt si softlink.txt nu au acelasi inode"
fi

echo "---Verificare fisiere dupa modificare continut original.txt:"
echo "TEST TEST TEST" > original.txt
echo -n "Continut original.txt:  "
cat original.txt
echo -n "Continut hardlink.txt:  "
cat "$dir"/hardlink.txt
echo -n "Continut softlink.txt:  "
cat "$dir"/softlink.txt

echo "---Verificare disponibilate fisiere dupa stergerea original.txt"
rm original.txt

if [ -f "$dir/hardlink.txt" ]; then
	echo -n "Continut hardlink.txt:  "
	cat "$dir"/hardlink.txt
else
	echo "hardlink.txt indisponibil"
fi

if [ -f "$dir"/softlink.txt ]; then
	echo -n "Continut softlink.txt:  "
	cat "$dir"/softlink.txt
else
	echo "softlink.txt indisponibil"
fi
