#!/bin/bash

read -p "Introdu cale dir:" dir
select user in $(cut -d ":" -f 1 /etc/passwd);do
	if [[ ! -z "$user" ]]; then
		echo "Ai selectat utilizator $user"
		break
	else
		echo "Selectie gresita"
	fi
done

select group in $(cut -d ':' -f 1  /etc/group);do
	if [[ ! -z $group ]]; then
		echo "Ai selectat grup $group"
		break
	else
		echo "Selectie gresita"
	fi
done

for fis in "$dir"/*;do
	if [[ -f "$fis" ]]; then
		chown "$user:$group" "$fis"
	fi
done

echo "Modificarile utilizator-grup au fost efectuate"

## Observatii
## For loop putea fi inlocuit cu chown -r care permite modificarea recursiva
## a directoarelor si fisierelor ce apartin de directorul selectat
 
## sudo
