#!/bin/bash

if [[ ! "$HOME" ]]; then
	export HOME="/home/admin"
fi
if [[ ! "$USER" ]]; then
	export USER="stefancapac"
fi
if [[ ! "$PATH" ]]; then
	export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/snap/bin"
fi
echo "HOME = $HOME, USER = $USER, PATH = $PATH"

